/**
 * LinkGo handlers.js
 * 书签操作处理：保存、编辑、删除、清空、设置 / Bookmark action handlers
 */

/* global LinkPlus */

/**
 * 执行保存指令（命令模式 Enter）
 */
LinkPlus.executeCommand = async function() {
  const { showToast, closeSearchPanel, loadBookmarks } = LinkPlus;
  const state = LinkPlus.state;
  
  // 1. 优先级：指令显式指定的#标签 > 搜索栏当前选中的分类Tab > 未分类
  let finalTag = state.commandTag;
  if (!finalTag && state.activeCategory && state.activeCategory !== 'all') {
    finalTag = state.activeCategory;
  }
  
  const title = state.commandTitle || document.title;
  const url = window.location.href;

  // 记录日志并检查是否为限制页面
  console.log('[LinkGo] ExecuteCommand Save:', { title, finalTag, activeCat: state.activeCategory });

  if (!url || url.startsWith('chrome://') || url.startsWith('about:') || url.startsWith('edge://')) {
    showToast('空白页或系统页无法存入书签', 'error');
    return;
  }

  try {
    const res = await chrome.runtime.sendMessage({
      action: 'save-bookmark', 
      title, 
      url, 
      tag: (finalTag === '未分类' ? null : finalTag),
    });

    const displayTag = finalTag || '未分类';

    if (res.success) {
      showToast(`已保存到"${displayTag}"`, 'success');
      await loadBookmarks();
      
      // 不再关闭面板，而是清空输入框并刷新显示
      const input = LinkPlus.shadowRoot.getElementById('linkplus-input');
      if (input) {
        input.value = '';
        state.searchQuery = '';
        state.isCommandMode = false;
        if (typeof LinkPlus.updateSearchIcon === 'function') LinkPlus.updateSearchIcon();
        if (typeof LinkPlus.updateCommandHint === 'function') LinkPlus.updateCommandHint();
      }
      LinkPlus.performSearch('');
    } else if (res.error === 'duplicate') {
      showToast(res.message, 'error');
    } else {
      showToast('保存失败：' + (res.message || '请重试'), 'error');
    }
  } catch (e) {
    console.error('[LinkGo] Failed to save bookmark:', e);
    showToast('保存失败，请重试', 'error');
  }
};

/**
 * 编辑书签（标题和分类）
 */
LinkPlus.handleEditBookmark = async function(bookmarkId, currentTitle, currentCategory) {
  // 获取当前书签的完整信息
  const bm = LinkPlus.state.bookmarks.find(b => b.id === bookmarkId);
  const folder = currentCategory || (bm ? bm.folder : '未分类');
  
  // 获取所有现有分类
  const categories = [...new Set([
    ...LinkPlus.state.bookmarks.map(b => b.folder),
    ...(LinkPlus.state.categories || [])
  ].filter(f => f && f !== 'QuickLink_Data'))];
  if (!categories.includes('未分类')) categories.unshift('未分类');
  
  // 生成分类选项
  const categoryOptions = categories.map(cat => 
    `<option value="${LinkPlus.escapeHtml(cat)}" ${cat === folder ? 'selected' : ''}>${LinkPlus.escapeHtml(cat)}</option>`
  ).join('');

  // 创建自定义编辑弹窗
  const modal = document.createElement('div');
  modal.className = 'linkplus-edit-modal';
  modal.innerHTML = `
    <div class="linkplus-edit-overlay">
      <div class="linkplus-edit-content">
        <div class="linkplus-edit-header">
          <h3>✏️ 编辑书签</h3>
          <button class="linkplus-edit-close" title="关闭">✕</button>
        </div>
        <div class="linkplus-edit-body">
          <div class="linkplus-edit-field">
            <label for="linkplus-edit-title">书签名称</label>
            <input type="text" id="linkplus-edit-title" value="${LinkPlus.escapeHtml(currentTitle)}" placeholder="输入书签名称..." autocomplete="off">
          </div>
          <div class="linkplus-edit-field">
            <label for="linkplus-edit-category">分类</label>
            <select id="linkplus-edit-category">
              ${categoryOptions}
              <option value="__new__">+ 新建分类...</option>
            </select>
            <input type="text" id="linkplus-edit-category-new" placeholder="输入新分类名称...">
          </div>
        </div>
        <div class="linkplus-edit-footer">
          <button class="linkplus-edit-action linkplus-edit-cancel">取消</button>
          <button class="linkplus-edit-action linkplus-edit-save">保存</button>
        </div>
      </div>
    </div>
  `;

  // 将编辑弹窗添加到 Shadow DOM 内部（和搜索面板在一起）
  const container = LinkPlus.shadowRoot.getElementById('linkplus-container');
  if (container) {
    container.appendChild(modal);
  } else {
    LinkPlus.shadowRoot.appendChild(modal);
  }

  // 获取元素引用
  const titleInput = modal.querySelector('#linkplus-edit-title');
  const categorySelect = modal.querySelector('#linkplus-edit-category');
  const categoryNewInput = modal.querySelector('#linkplus-edit-category-new');
  const closeBtn = modal.querySelector('.linkplus-edit-close');
  const cancelBtn = modal.querySelector('.linkplus-edit-cancel');
  const saveBtn = modal.querySelector('.linkplus-edit-save');

  // 分类下拉选择事件
  categorySelect.addEventListener('change', () => {
    if (categorySelect.value === '__new__') {
      categoryNewInput.style.display = 'block';
      categoryNewInput.focus();
    } else {
      categoryNewInput.style.display = 'none';
    }
  });

  // 关闭弹窗函数
  const closeModal = () => {
    modal.remove();
    // 移除全局 ESC 事件监听
    document.removeEventListener('keydown', onEsc);
  };

  // 绑定关闭事件
  closeBtn.addEventListener('click', closeModal);
  cancelBtn.addEventListener('click', closeModal);
  modal.querySelector('.linkplus-edit-overlay').addEventListener('click', (e) => {
    if (e.target === e.currentTarget) closeModal();
  });

  // ESC 关闭
  const onEsc = (e) => {
    if (e.key === 'Escape') {
      closeModal();
    }
  };
  document.addEventListener('keydown', onEsc);

  // 聚焦到标题输入框
  setTimeout(() => titleInput.focus(), 0);

  // 保存处理
  saveBtn.addEventListener('click', async () => {
    const newTitle = titleInput.value.trim();
    // 获取分类：如果是新建分类则使用输入框的值，否则使用下拉选择的值
    let newCategory = categorySelect.value === '__new__' 
      ? categoryNewInput.value.trim() 
      : categorySelect.value;

    if (!newTitle) {
      LinkPlus.showToast('书签名称不能为空', 'error');
      return;
    }

    const titleChanged = newTitle !== currentTitle;
    const categoryChanged = newCategory !== folder && newCategory !== (folder === '未分类' ? '' : folder);

    if (!titleChanged && !categoryChanged) {
      closeModal();
      return;
    }

    try {
      const res = await chrome.runtime.sendMessage({
        action: 'update-bookmark',
        bookmarkId,
        title: titleChanged ? newTitle : undefined,
        category: categoryChanged ? newCategory : undefined
      });

      if (res.success) {
        LinkPlus.showToast('书签已更新', 'success');
        closeModal();

        await LinkPlus.loadBookmarks();
        LinkPlus.performSearch(LinkPlus.state.searchQuery);
      } else {
        LinkPlus.showToast('更新失败：' + res.error, 'error');
      }
    } catch (e) {
      console.error('[LinkGo] Failed to update bookmark:', e);
      LinkPlus.showToast('更新失败，请重试', 'error');
    }
  });

  // Enter 键保存
  titleInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      saveBtn.click();
    }
  });
  // 如果当前是新建分类输入框，也支持 Enter 保存
  if (categoryNewInput) {
    categoryNewInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        saveBtn.click();
      }
    });
  }
};

/**
 * 删除单个书签
 */
LinkPlus.handleDeleteBookmark = async function(bookmarkId, bookmarkTitle) {
  if (!confirm(`确定要删除书签"${bookmarkTitle}"吗？\n\n此操作无法撤销。`)) return;

  try {
    const res = await chrome.runtime.sendMessage({
      action: 'delete-bookmark', bookmarkId,
    });
    
    if (res.success) {
      LinkPlus.showToast('已删除书签', 'success');
      await LinkPlus.loadBookmarks();
      LinkPlus.performSearch(LinkPlus.state.searchQuery);
    } else {
      LinkPlus.showToast('删除失败：' + res.error, 'error');
    }
  } catch (e) {
    console.error('[LinkGo] Failed to delete bookmark:', e);
    LinkPlus.showToast('删除失败，请重试', 'error');
  }
};

/**
 * 清空所有收藏
 */
LinkPlus.handleClearAll = async function() {
  if (!confirm('⚠️ 确定要清空所有收藏吗？\n\n此操作将删除所有书签，无法撤销。')) return;

  try {
    const res = await chrome.runtime.sendMessage({ action: 'clear-all-bookmarks' });
    if (res.success) {
      LinkPlus.showToast(`已清空 ${res.count} 个收藏`, 'success');
      await LinkPlus.loadBookmarks();
      LinkPlus.performSearch('');
    } else {
      LinkPlus.showToast('清空失败：' + res.error, 'error');
    }
  } catch (e) {
    console.error('[LinkGo] Failed to clear bookmarks:', e);
    LinkPlus.showToast('清空失败，请重试', 'error');
  }
};

/**
 * 新建分类
 */
LinkPlus.handleCreateCategory = async function() {
  const name = prompt('请输入新分类名称');
  const categoryName = name ? name.trim() : '';
  if (!categoryName) return;

  try {
    const res = await chrome.runtime.sendMessage({ action: 'create-category', name: categoryName });
    if (res.success) {
      LinkPlus.state.activeCategory = res.data.name;
      LinkPlus.showToast(`已新建分类"${res.data.name}"`, 'success');
      await LinkPlus.loadBookmarks();
      LinkPlus.performSearch(LinkPlus.state.searchQuery || '');
    } else {
      LinkPlus.showToast('新建分类失败：' + res.error, 'error');
    }
  } catch (e) {
    console.error('[LinkGo] Failed to create category:', e);
    LinkPlus.showToast('新建分类失败，请重试', 'error');
  }
};

/**
 * 打开快捷键设置页面
 */
LinkPlus.handleOpenSettings = async function() {
  try {
    await chrome.runtime.sendMessage({ action: 'open-settings' });
    LinkPlus.showToast('请在打开的页面中设置快捷键', 'success');
  } catch (e) {
    console.error('[LinkGo] Failed to open settings:', e);
    LinkPlus.showToast('无法打开设置页面', 'error');
  }
};
